from .headmouse_singleton import HeadmouseSingleton
from .headmouse import Headmouse
